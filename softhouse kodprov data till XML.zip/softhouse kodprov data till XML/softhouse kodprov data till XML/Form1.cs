﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace softhouse_kodprov_data_till_XML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            string[] data_rows;
            string[] data_row_details;
            string[] data_alloc_1001;
            string[] data_alloc_1002;
            string[] data_alloc_1003;
            string[] data_alloc_1004;
            string[] data_alloc_1005;
            string[] data_alloc_1006;
            string[] data_alloc_1007;
            string[] data_alloc_1008;

            int person_fields_phone_address_added = 0;
            int duplicate_family_tag = 0;

            int null_family_members = 0;

            var data = AppDomain.CurrentDomain.BaseDirectory.Replace("\\", "/") + "data.txt";
            var file_data = File.ReadAllText(data);

            //System.Diagnostics.Debug.WriteLine(file_data);



            data_rows = file_data.Split(new string[] { "\r\n" }, StringSplitOptions.None);

            char[] first_char = file_data.ToCharArray();
            System.Diagnostics.Debug.WriteLine(data_rows.Length);

            /*
             <people>
                <person>
                    <firstname>Elof</firstname>
                    <lastname>Sundin</lastname>
                    <address>
                        <street>S:t Johannesgatan 16</street>
                        <city>Uppsala</city>
                        <zip>75330</zip>
                    </address>
                    <phone>
                        <mobile>073-101801</mobile>
                        <landline>018-101801</landline>
                    </phone>
                    <family>
                        <name>Hans</name>
                        <born>1967</born>
                        <address>...</address>
                    </family>
                    <family>...</family>
                </person>
                <person>...</person>
            </people>


             */

            var data_output = "<people>\r\n";

            
            for (var x = 0; x < data_rows.Length; x++)
            {
                null_family_members = 0;
                System.Diagnostics.Debug.WriteLine(data_rows[x]);
                first_char = data_rows[x].ToCharArray();
                System.Diagnostics.Debug.WriteLine(first_char[0]);

                data_row_details = data_rows[x].Split(new string[] { "|" }, StringSplitOptions.None);

                //p == begin new <person>
                //t == telephone
                //a == address
                //f == family members
                if (first_char[0].ToString() == "P")
                {
                    data_output += "\t<person>\r\n";
                    
                    data_output += "\t\t<firstname>" + data_row_details[1]+ "</firstname>\r\n";
                    data_output += "\t\t<lastname>" + data_row_details[2] + "</lastname>\r\n";
                }
                if (first_char[0].ToString() == "T")
                {
                    data_output += "\t\t<phone>\r\n";
                    data_output += "\t\t\t<mobile>" + data_row_details[1] + "</mobile>\r\n";
                    data_output += "\t\t\t<landline>" + data_row_details[2] + "</landline>\r\n";
                    data_output += "\t\t</phone>\r\n";
                }
                if (first_char[0].ToString() == "A")
                {
                    data_output += "\t\t<address>\r\n";
                    data_output += "\t\t\t<street>" + data_row_details[1] + "</street>\r\n";
                    data_output += "\t\t\t<city>" + data_row_details[2] + "</city>\r\n";

                    /*
                    error
                    zip code not filled (breaks database structure) (field definition not present)
                    P|Boris|Johnson
                    A|10 Downing Street|London

                    correct database structure would be
                    ---->
                    A|10 Downing Street|London|
                   */


                    try { data_output += "\t\t\t<zip>" + data_row_details[3] + "</zip>\r\n"; }
                    catch (Exception) { data_output += "\t\t\t<zip>null</zip>\r\n"; }
                    data_output += "\t\t</address>\r\n";
                }
                if (first_char[0].ToString() == "F")
                {
                    null_family_members++;
                    data_output += "\t\t<family>\r\n";
                    data_output += "\t\t\t<name>" + data_row_details[1] + "</name>\r\n";
                    data_output += "\t\t\t<born>" + data_row_details[2] + "</born>\r\n";

                    //dynamic fields below
                    //address
                    //phone

                    //loop until "A" or "T" is not present
                    //dynamic amounts of (family members)
                    for (var e = 0; e < 1000; e++) {
                        
                        
                        //first check
                        if (data_rows[x+1].ToCharArray()[0].ToString() == "A" || data_rows[x + 1].ToCharArray()[0].ToString() == "T"){
                            x++;
                            data_row_details = data_rows[x].Split(new string[] { "|" }, StringSplitOptions.None);
                            //process
                            if(data_rows[x].ToCharArray()[0].ToString() == "A"){
                                data_output += "\t\t\t<address>\r\n";
                                data_output += "\t\t\t\t<street>" + data_row_details[1] + "</street>\r\n";
                                data_output += "\t\t\t\t<city>" + data_row_details[2] + "</city>\r\n";
                                data_output += "\t\t\t\t<zip>" + data_row_details[3] + "</zip>\r\n";
                                data_output += "\t\t\t</address>\r\n";
                            }
                            if(data_rows[x].ToCharArray()[0].ToString() == "T"){
                                data_output += "\t\t\t<phone>\r\n";
                                data_output += "\t\t\t\t<mobile>" + data_row_details[1] + "</mobile>\r\n";
                                data_output += "\t\t\t\t<landline>" + data_row_details[2] + "</landline>\r\n";
                                data_output += "\t\t\t</phone>\r\n";
                            }
                            person_fields_phone_address_added++;
                            //second check (if also phone number exists)
                            if (data_rows[x + 1].ToCharArray()[0].ToString() == "A" || data_rows[x + 1].ToCharArray()[0].ToString() == "T"){
                                x++;
                                data_row_details = data_rows[x].Split(new string[] { "|" }, StringSplitOptions.None);
                                //process
                                if(data_rows[x].ToCharArray()[0].ToString() == "A"){
                                    data_output += "\t\t\t<address>\r\n";
                                    data_output += "\t\t\t\t<street>" + data_row_details[1] + "</street>\r\n";
                                    data_output += "\t\t\t\t<city>" + data_row_details[2] + "</city>\r\n";
                                    data_output += "\t\t\t\t<zip>" + data_row_details[3] + "</zip>\r\n";
                                    data_output += "\t\t\t</address>\r\n";
                                }
                                if(data_rows[x].ToCharArray()[0].ToString() == "T"){
                                    data_output += "\t\t\t<phone>\r\n";
                                    data_output += "\t\t\t<mobile>" + data_row_details[1] + "</mobile>\r\n";
                                    data_output += "\t\t\t<landline>" + data_row_details[2] + "</landline>\r\n";
                                    data_output += "\t\t\t</phone>\r\n";
                                }
                                person_fields_phone_address_added++;
                            }
                        }
                        
                        //if personal information to family person are present (add </family> )
                        if (person_fields_phone_address_added > 0)
                        {
                            
                            if (data_rows[x + 1].ToCharArray()[0].ToString() == "P")
                            {
                                data_output += "\t\t</family>\r\n";
                                
                            }
                            else
                            {
                                data_output += "\t\t</family>\r\n";
                            }

                            break;
                        }
                    }
                }
            }

            data_output += "\t</person>\r\n";
            data_output += "</people>\r\n";
            System.Diagnostics.Debug.WriteLine(data_output);

            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory.Replace("\\", "/")+"data_output.xml", data_output);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
